import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import controlP5.*; 
import ddf.minim.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class SpaceExploreFinal extends PApplet {

/**
 * Title: Project Final- Space Explore
 * Name: Ma\u00eblle Morin
 * Date: 19-04-2016
 * Description: Create a prototype for the final project where almost all the functionalities of your code is there. 
 * The prototype needs to use the 4 OOP principles: Abstraction, Encapsulation, Inheritence and polymorphism. 
 * Space Explore is a space simulation that allows user to navigate into a 3D world, to interact with it and to customize it. 
 * Many planets are rotating around a sun and many particles are attracted by planets. A user interface alows the player to customize the 
 * physics values of the planets.
 
 
 * Keys used to navigate in the Space World : all the arrow keys
 * key used to add particles: "+"
 
 * Copyright (C) <2015>  <Maelle Morin>
 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

//imports the external library  controlP5


//imports the external library minim


//initializes the external library
Minim minim;

//delcares the audio player that will play the background music of the game
AudioPlayer ambientMusic;

//declares the universe
Universe universe;

//declares the control panel
ControlPanel controlPanel;

//declares a start menu
StartMenu myMenu;

//tells if the game starts or not
boolean startGame = false;

//initialize a font
PFont font;

//this function initializes environment
public void setup() {

  //sets noStroke and the size of the display, giving a P3D render mode 
  noStroke();
  
  

  //instatiates the univer, control panel and starting menu
  universe = new Universe();
  controlPanel = new ControlPanel(this, universe);
  myMenu = new StartMenu();

  //initializes the minim instance
  minim = new Minim(this);

  //initializes the ambient music
  //Music by Symbiants under the Licence Creative Commons
  //https://www.jamendo.com/track/1250957/spacex
  ambientMusic = minim.loadFile("Symbiants_-_SpaceX.mp3");

  //adds and displays controller of controlPanel
  controlPanel.addControlPanel();

  //creates font
  font = createFont("VCR_OSD_MONO_1.001.ttf", 12);
}

//this function draws the animation
public void draw() {

  //resizes the background image
  universe.getBackground().resize(width, height);

  //resets the background 
  background(universe.getBackground());

  //if the game is not started
  if (startGame == false) {

    //displays the start menu
    myMenu.display();
  }

  //if the game is started
  if (startGame == true) {

    pushMatrix();
    //translates the systems so the planets will turn around the sun
    translate(width/2, height/2, 0);

    //applies a light function on the 3D objects
    lights();

    //applies a blue and white pointlights
    pointLight(0, 0, 255, 10, 0, 100);
    pointLight(30, 30, 30, 100, 100, 100);

    //calls the display function of the universe
    universe.display();

    popMatrix();

    //calls the collision function of the universe
    universe.collision();

    //displays the spaceship's cockpit
    controlPanel.displayCockpit();

    //displays the position of the spaceship
    controlPanel.spaceshipPosition(universe.myCamera.getXLocation(), universe.myCamera.getZLocation());
  }
}

////This function return what's in it when a key is pressed
public void keyPressed() {

  //calls the keyPressed function of the camera and controlPanel
  universe.myCamera.keyPressed();
  controlPanel.keyPressed();

  //if the s key is pressed
  if (key == 's') {

    //startGame becomes true
    startGame = true;

    //plays the ambient music and loops it 10 times
    ambientMusic.play();
    ambientMusic.loop(10);
  }
}

//this function calls the keyReleased function of the camera
public void keyReleased() {
  universe.myCamera.keyReleased();
}
/**
 * A class that updates the position of the camera with the help of the arrow Keys and the mouse. This class has a a cameraUpdate()
 * function that sets where the user is looking at and a locationUpdate() function that sets the actual position of the update
 * This class comes from the original code of Ryan D  
 * found February 14, 2016 on (http://www.openprocessing.org/sketch/12557)
 */

class Camera {

  //Camera Variables

  //accelerations of the spaceship
  float acceleration = 0;
  float deceleration = 0;
  float rightAcceleration = 0;
  float leftAcceleration = 0;

  //speedLimit
  float speedLimit = 500;

  //tells if the the spaceship moves or not
  boolean startEngine = false;

  //camera location
  PVector location;

  //scene center or where the user is looking at
  PVector sceneCenter;

  //difference of tx-x and tz-z
  float xComp, zComp;

  //angle of the camera
  float angle;

  //Movement Variables
  boolean moveUp, moveDown, moveLeft, moveRight;

  //Constants

  //height of the camera in the 3D world
  int standHeight = 50;

  //speed of the mouvement of the camera when changing cameraLocation(), a bigger number = slower
  float movementSpeed = 170;  

  //sensitivity to change the locationUpdate(), sensitivy of the mouse when changing where the users is looking at, a bigger numer = slower
  float sensitivity = 35;

  //Center of POV, mouse must be stillBox away from center to move
  int stillBox = 100;       

  //distance from camera to camera target in lookmode
  int cameraDistance = 1000;  

  //Constructor.
  Camera() {

    //camera initialization
    location = new PVector(0, 0, (height/2.0f) + 3100 / tan(PI*60.0f / 360.0f));

    sceneCenter = new PVector(0, height/2, 0);

    //difference in x and y axis where my eyes is pointing and where the center of the scene is
    xComp = sceneCenter.x - location.x;
    zComp = sceneCenter.z - location.z;

    //sets angle of camera to 0
    angle = 0;

    //Movement Initialization
    moveUp = false;
    moveDown = false;
    moveLeft = false;
    moveRight = false;
  }

  //this function call the locationUpdate function and also call the camera function
  public void display() {
    locationUpdate();
    camera(location.x, location.y, location.z, sceneCenter.x, sceneCenter.y, sceneCenter.z, 0, 1, 0);
  }

  //this function updates the position of the camera in the 3D space
  public void locationUpdate() {

    //if moveUp is true
    if (moveUp) {

      //sets startEngine tot true
      startEngine = true;

      // accelerates of 4 toward the screen
      acceleration -= 4;

      //updates all x and z parameters of the camera to move toward the screen with an acceleration
      location.z += zComp/(movementSpeed + acceleration);
      sceneCenter.z+= zComp/(movementSpeed + acceleration);
      location.x += xComp/(movementSpeed);
      sceneCenter.x+= xComp/(movementSpeed);

      //else
    } else {

      //if the spaceship is moving
      if (startEngine == true) {

        //if the spaceship goes at a speed smaller than the speedLimit
        if ((movementSpeed + acceleration) < speedLimit) {

          //accelera toward the users, to give a feel of deceleration
          acceleration += 6;

          //updates all x and z parameters of the camera to move forward the screen with a deceleration
          location.z  += zComp/ (movementSpeed + acceleration);
          sceneCenter.z += zComp/ (movementSpeed + acceleration);
          location.x += xComp/(movementSpeed);
          sceneCenter.x += xComp/(movementSpeed);
        }
      }
    }
    //if moveDown is true
    if (moveDown) {

      //decelerates
      deceleration +=  1.5f;

      //updates all x and z parameters of the camera to move forward the screen with a deceleration
      location.z  -= zComp/ (movementSpeed + deceleration);
      sceneCenter.z -= zComp/ (movementSpeed + deceleration);
      location.x -= xComp/(movementSpeed);
      sceneCenter.x -= xComp/(movementSpeed);
    }

    //if moveRight is true
    else if (moveRight) {

      //accelerates toward the right
      rightAcceleration += 1.5f;

      //updates all x and z parameters of the camera to move to the right of the screen with a acceleration
      location.z += xComp/movementSpeed; 
      sceneCenter.z+= xComp/movementSpeed;
      location.x -= zComp/(movementSpeed + rightAcceleration);
      sceneCenter.x-= zComp/(movementSpeed + rightAcceleration);
    }

    //if moveLeft is true
    else if (moveLeft) {

      //accelerates toward the left
      leftAcceleration += 1.5f;

      //updates all x and z parameters of the camera to move to the left of the screen with a acceleration
      location.z -= xComp/movementSpeed; 
      sceneCenter.z-= xComp/movementSpeed;
      location.x += zComp/(movementSpeed + leftAcceleration);
      sceneCenter.x+= zComp/(movementSpeed + leftAcceleration);
    }
  }

  //return the camera location
  public PVector getLocation() {
    return location;
  }

  //return the x location of the camera
  public float getXLocation() {
    return location.x;
  }

  //return the z location of the camera
  public float getZLocation() {
    return location.z;
  }

  //set a newLocation to the camera
  public void setLocation(PVector newLocation) {
    location = newLocation;
  }

  //this function changes boolean status when arrowKeys are pressed
  public void keyPressed() {
    if (keyPressed) {
      if (key == CODED) {
        if (keyCode == UP) {
          moveUp = true;
        } else if (keyCode == DOWN) {
          moveDown = true;
        } else if (keyCode == LEFT) {
          moveLeft = true;
        } else if (keyCode == RIGHT) {
          moveRight = true;
        }
      }
    }
  }

  //this function changes boolean status when arrowKeys are released
  public void keyReleased() {
    if (key == CODED) {
      if (keyCode == UP) {
        moveUp = false;
      } else if (keyCode == DOWN) {
        moveDown = false;
      } else if (keyCode == LEFT) {
        moveLeft = false;
      } else if (keyCode == RIGHT) {
        moveRight = false;
      }
    }
  }
}
/**
 * A abstract class describing a physical celestial object (Pshape) in a 3D space. The celestial object has a location (x,y, z), a mass, 
 * a orignal mass, a texture image. This class is not displayed in the main tab, it is only used as a Parent class
 */
abstract class CelestialObject {

  //location
  PVector location;

  //mass
  float mass;

  //orignal mass
  float originalMass;

  //a shape for the celestial object
  PShape shape;

  //PImage for the texture
  PImage img;

  //Constructor. CelestialObject can be created with a locaiton, mass and texturefile name
  CelestialObject(PVector location_, float mass_, String textureFileName) {

    //Assigns values to data and new PVector to data
    location = location_;
    mass = mass_;
    originalMass = mass;

    //creates a sphere
    shape = createShape(SPHERE, mass);

    //loads textures
    img = loadImage(textureFileName);
  }

  //this function displays the celestial object
  public void display() {

    //scales the object according to its original mass
    shape.scale(mass/originalMass);

    //sets texture to the shape
    shape.setTexture(img);

    //draw the shpere
    shape(shape);
  }

  //updates the position of the celestial object. Need to be overriden
  public void update() {
  }

  //returns location of the celestial object
  public PVector getLocation() {
    return location;
  }

  //returns mass of the celestial object
  public float getMass() {
    return mass;
  }

  //sets a new mass
  public void setMass(float newMass) {
    mass = newMass;
  }

  //----All the followed functions need to be overriden in the Planet class--------///

  //sets a new speed orbit
  public void setSpeedOrbit(float newSpeedOrbit) {
  }

  //sets a new orbit
  public void setRadius(float newRadius) {
  }

  //sets a new rotation
  public void setSpeedRotation(float newSpeedRotation) {
  }

  //sets a new gravitaiton field
  public void setGravitationalField(float newGravitationalField) {
  }

  //sets a new planet Name
  public void setPlanetName(String newPlanetName) {
  }

  //sets a new state to the boolean displayPlanetNames
  public void setStateDisplayPlanetNames(boolean newState) {
  }

  //does action when key is pressed
  public void keyPressed() {
  }
}
/**
 * This class is the view and controller of the spaceship. All the controllers of the UI are contained in this class. 
 * The class class displays the spaceship cockpit and the spaceship control panel
 */
class ControlPanel {

  //initializes the controlP5 library
  ControlP5 cp5;

  //a reference to the model universe
  Universe universe;

  //instantiates the cockpit image
  PImage cockpit;

  //x and y offset of the orbit knob
  final float  X_OFFSET_ORBIT_KNOB = 180;
  final float Y_OFFSET_ORBIT_KNOB = 230; 

  //x and y offset of the rotation knob
  final float X_OFFSET_ROTATION_KNOB = 80;
  final float Y_OFFSET_ROTATION_KNOB = 230;

  //x and y offset of the mass slider
  final float X_OFFSET_MASS_SLIDER = 180;
  final float Y_OFFSET_MASS_SLIDER = 130;

  //x and y offset of the radisu slider
  final float X_OFFSET_RADIUS_SLIDER = 180;
  final float Y_OFFSET_RADIUS_SLIDER = 90;

  //x and y offset of the gravitation slider
  final float X_OFFSET_GRAVITATION_SLIDER = 30;
  final float Y_OFFSET_GRAVITATION_SLIDER = 180;

  //x and y offset of the toggle
  final float X_OFFSET_TOGGLE = 80;
  final float Y_OFFSET_TOGGLE = 230;

  //x and y offset of the textField
  final float X_OFFSET_TEXTFIELD = 20;
  final float Y_OFFSET_TEXTFIELD = 230;

  //size of the knobs
  final float KNOB_SIZE = 33;

  //number of tickmarks aroun a knob
  final int NUM_TICKMARKS = 10;

  //number of tickmarks on a slider
  final int NUM_SLIDER_TICKMARKS = 3;

  //length of the tickmarks
  final int KNOB_TICKMARKS_LENGTH  = 4;

  //width and height of the vertical slider
  final int VERTICAL_SLIDER_WIDTH = 25;
  final int VERTICAL_SLIDER_HEIGHT = 100;

  ////width and height of the horizontal sliders
  final int HORIZONTAL_SLIDER_WIDTH = 150;
  final int HORIZONTAL_SLIDER_HEIGHT = 15;

  //width and height of the buttons
  final int BUTTON_WIDTH = 100;
  final int BUTTON_HEIGHT = 40;

  //width and height of the textfield
  final int TEXTFIELD_WIDTH = 200;
  final int TEXTFIELD_HEIGHT = 20;

  //width and height of the Toggle
  final int TOGGLE_WIDHT = 70;
  final int TOGGLE_HEIGHT = 30;

  //range of the planets speed orbit around the sun
  final float MIN_ORBIT = 70000;
  final float MAX_ORBIT = 3000;

  //range of the planets rotation around themselves
  final float MIN_ROTATION = 0;
  final float MAX_ROTATION = 40;

  //range of the radius/distance between planets and sun
  final float MIN_RADIUS = 800;
  final float MAX_RADIUS = 4500;

  //range of the gravitational field of the planets
  final float MIN_GRAVITATION = 100;
  final float MAX_GRAVITATION = 1000;

  //foreground, background and active color of the controllers
  final int FOREGROUND_COLOR = color(35, 232, 174);
  final int BACKGROUND_COLOR = color(26, 78, 77);
  final int ACTIVE_COLOR = color(124, 255, 217);

  //Starting values(speed orbit, mass, radius, gravitationField) of the blue planet
  final float BLUE_SPEED_ORBIT = 20000;
  final float BLUE_MASS = 60;
  final float BLUE_RADIUS = 800;
  final float BLUE_GRAVITATION = 200;

  //Starting values(speed orbit, mass, radius, gravitationField) of the pink planet
  final float PINK_SPEED_ORBIT = 28000;
  final float PINK_MASS = 100;
  final float PINK_RADIUS = 1300;
  final float PINK_GRAVITATION = 200;

  //Starting values(speed orbit, mass, radius, gravitationField) of the green planet
  final float GREEN_SPEED_ORBIT = 45000;
  final  float GREEN_MASS = 75;
  final float GREEN_RADIUS = 2000;
  final float GREEN_GRAVITATION = 100;

  //Starting values(speed orbit, mass, radius, gravitationField) of the purple planet
  final float PURPLE_SPEED_ORBIT = 21000;
  final float PURPLE_MASS = 185;
  final float PURPLE_RADIUS = 3000;
  final float PURPLE_GRAVITATION = 300;

  //Starting values(speed orbit, mass, radius, gravitationField) of the red planet
  final float RED_SPEED_ORBIT = 30000;
  final float RED_MASS = 40;
  final float RED_RADIUS = 3600;
  final float RED_GRAVITATION = 100;

  //Starting values(speed orbit, mass, radius, gravitationField) of the orange planet
  final float ORANGE_SPEED_ORBIT = 60000;
  final float ORANGE_MASS = 90;
  final float ORANGE_RADIUS = 4000;
  final float ORANGE_GRAVITATION = 200;

  //Constructor with a PApplet and universe parameter
  ControlPanel(PApplet thePApplet, Universe universe) {
    this.universe = universe;

    //instantiate the user interface controlP5
    cp5 = new ControlP5(thePApplet);

    //load the cockpit image
    //Design by Maelle Morin
    //Inspired by the spaceship in the game Evochron Mercenary
    cockpit = loadImage("spaceship.png");
  }

  //function to add all the controllers of the UI
  public void addControlPanel() {
    addTabs();
    addControllersPlanets();
    addControllerSpaceship();
  }

  //adds the tabs
  public void addTabs() {

    //changes the name of the default tab
    cp5.getTab("default")
      .setLabel("Menu")
      ;

    //creates a tab for the general spaceship
    cp5.addTab("Spaceship");

    //creates 6 tabs for each planets
    cp5.addTab("Blue Planet");
    cp5.addTab("Pink Planet");
    cp5.addTab("Green Planet");
    cp5.addTab("Purple Planet");
    cp5.addTab("Red Planet");
    cp5.addTab("Orange Planet");
  }

  //adds all the planets controllers
  public void addControllersPlanets() {
    addControllerBluePlanet();
    addControllerPinkPlanet();
    addControllerGreenPlanet();
    addControllerPurplePlanet();
    addControllerRedPlanet();
    addControllerOrangePlanet();
  }

  //adds all the general spaceship controllers
  public void addControllerSpaceship() {
    addButtons();
    addToggle();
  }

  //adds a toggle
  public void addToggle() {
    cp5.addToggle("displayNames")

      //sets position, size, value, mode of the toggle
      .setPosition(width/2 + X_OFFSET_TOGGLE, height - Y_OFFSET_TOGGLE)
      .setSize(TOGGLE_WIDHT, TOGGLE_HEIGHT)
      .setValue(false)
      .setMode(ControlP5.SWITCH)

      //sets the foreground, background and active color
      .setColorForeground(FOREGROUND_COLOR)
      .setColorBackground(BACKGROUND_COLOR)
      .setColorActive(ACTIVE_COLOR)
      ;

    //Places the toogle in the spaceship tab
    cp5.getController("displayNames").moveTo("Spaceship");
  }

  //add the buttons
  public void addButtons() {

    //adds a button to add blue particles
    cp5.addButton("blue_Particles")

      //sets value, position, size, foreground, background and active color of the button
      .setValue(1)
      .setPosition(width/2 - 190, height - 230)
      .setSize(BUTTON_WIDTH, BUTTON_HEIGHT)
      .setColorForeground(FOREGROUND_COLOR)
      .setColorBackground(BACKGROUND_COLOR)
      .setColorActive(ACTIVE_COLOR)
      ;

    //adds a button to add pink particles
    cp5.addButton("pink_Particles")

      //sets value, position, size, foreground, background and active color of the button
      .setValue(2)
      .setPosition(width/2 - 50, height - 230)
      .setSize(BUTTON_WIDTH, BUTTON_HEIGHT)
      .setColorForeground(FOREGROUND_COLOR)
      .setColorBackground(BACKGROUND_COLOR)
      .setColorActive(ACTIVE_COLOR)
      ;

    //adds a button to add green particles
    cp5.addButton("green_Particles")

      //sets value, position, size, foreground, background and active color of the button
      .setValue(2)
      .setValue(3)
      .setPosition(width/2 - 190, height - 170)
      .setSize(BUTTON_WIDTH, BUTTON_HEIGHT)
      .setColorForeground(FOREGROUND_COLOR)
      .setColorBackground(BACKGROUND_COLOR)
      .setColorActive(ACTIVE_COLOR)
      ;

    //adds a button to add purple particles
    cp5.addButton("purple_Particles")

      //sets value, position, size, foreground, background and active color of the button
      .setValue(4)
      .setPosition(width/2 - 50, height - 170)
      .setSize(BUTTON_WIDTH, BUTTON_HEIGHT)
      .setColorForeground(FOREGROUND_COLOR)
      .setColorBackground(BACKGROUND_COLOR)
      .setColorActive(ACTIVE_COLOR)
      ;

    //adds a button to add red particles
    cp5.addButton("red_Particles")

      //sets value, position, size, foreground, background and active color of the button
      .setValue(5)
      .setPosition(width/2 - 190, height - 110)
      .setSize(BUTTON_WIDTH, BUTTON_HEIGHT)
      .setColorForeground(FOREGROUND_COLOR)
      .setColorBackground(BACKGROUND_COLOR)
      .setColorActive(ACTIVE_COLOR)
      ;

    //adds a button to add orange particles
    cp5.addButton("orange_Particles")

      //sets value, position, size, foreground, background and active color of the button
      .setValue(6)
      .setPosition(width/2 - 50, height - 110)
      .setSize(BUTTON_WIDTH, BUTTON_HEIGHT)
      .setColorForeground(FOREGROUND_COLOR)
      .setColorBackground(BACKGROUND_COLOR)
      .setColorActive(ACTIVE_COLOR)
      ;

    //places all the buttons in the spaceship tab
    cp5.getController("blue_Particles").moveTo("Spaceship");
    cp5.getController("pink_Particles").moveTo("Spaceship");
    cp5.getController("green_Particles").moveTo("Spaceship");
    cp5.getController("purple_Particles").moveTo("Spaceship");
    cp5.getController("red_Particles").moveTo("Spaceship");
    cp5.getController("orange_Particles").moveTo("Spaceship");
  }

  //adds controllers to change parameters of the blue planet
  public void addControllerBluePlanet() {

    //adds a knob to change the speed orbit
    cp5.addKnob("speedOrbit1")

      //sets the range, value, position, radius, number and length of tickmarks, 
      //drag direction, foreground, background and active color of the knob
      .setRange(MIN_ORBIT, MAX_ORBIT)
      .setValue(BLUE_SPEED_ORBIT)
      .setPosition(width/2 - X_OFFSET_ORBIT_KNOB, height - Y_OFFSET_ORBIT_KNOB)
      .setRadius(KNOB_SIZE)
      .setNumberOfTickMarks(NUM_TICKMARKS)
      .setTickMarkLength(KNOB_TICKMARKS_LENGTH)
      .setDragDirection(Knob.HORIZONTAL)
      .setColorForeground(FOREGROUND_COLOR)
      .setColorBackground(BACKGROUND_COLOR)
      .setColorActive(ACTIVE_COLOR)
      ;

    //adds a knob to change the rotation 
    cp5.addKnob("speedRotation1")

      //sets the range, value, position, radius, number and length of tickmarks, 
      //drag direction, foreground, background and active color of the knob
      .setRange(MIN_ROTATION, MAX_ROTATION)
      .shuffle()
      .setPosition(width/2 - X_OFFSET_ROTATION_KNOB, height - Y_OFFSET_ROTATION_KNOB)
      .setRadius(KNOB_SIZE)
      .setNumberOfTickMarks(NUM_TICKMARKS)
      .setTickMarkLength(KNOB_TICKMARKS_LENGTH)
      .setDragDirection(Knob.HORIZONTAL)
      .setColorForeground(FOREGROUND_COLOR)
      .setColorBackground(BACKGROUND_COLOR)
      .setColorActive(ACTIVE_COLOR)
      ;

    //adds a slider to change the mass
    cp5.addSlider("mass1")

      //sets the range, value, size, position,  number  of tickmarks, 
      //foreground, background and active color of the slider
      .setRange(BLUE_MASS - 1, BLUE_MASS + 1)
      .setValue(BLUE_MASS)
      .setSize(HORIZONTAL_SLIDER_WIDTH, HORIZONTAL_SLIDER_HEIGHT)
      .setPosition(width/2 - X_OFFSET_MASS_SLIDER, height - Y_OFFSET_MASS_SLIDER)
      .setNumberOfTickMarks(NUM_SLIDER_TICKMARKS)
      .setColorForeground(FOREGROUND_COLOR)
      .setColorBackground(BACKGROUND_COLOR)
      .setColorActive(ACTIVE_COLOR)
      ;

    //adds a slider to change the radius
    cp5.addSlider("radius1")

      //sets the range, value, size, position, 
      //foreground, background and active color of the slider
      .setRange(MIN_RADIUS, MAX_RADIUS)
      .setValue(BLUE_RADIUS)
      .setSize(HORIZONTAL_SLIDER_WIDTH, HORIZONTAL_SLIDER_HEIGHT)
      .setPosition(width/2 - X_OFFSET_RADIUS_SLIDER, height - Y_OFFSET_RADIUS_SLIDER)
      .setColorForeground(FOREGROUND_COLOR)
      .setColorBackground(BACKGROUND_COLOR)
      .setColorActive(ACTIVE_COLOR)
      ;

    //adds a slider to change the gravitational field
    cp5.addSlider("gravitationalField1") 

      //sets the range, value, size, position, 
      //foreground, background and active color of the slider
      .setRange(MIN_GRAVITATION, MAX_GRAVITATION)
      .setValue(BLUE_GRAVITATION)
      .setSize(VERTICAL_SLIDER_WIDTH, VERTICAL_SLIDER_HEIGHT)
      .setPosition(width/2 + X_OFFSET_GRAVITATION_SLIDER, height - Y_OFFSET_GRAVITATION_SLIDER)
      .setColorForeground(FOREGROUND_COLOR)
      .setColorBackground(BACKGROUND_COLOR)
      .setColorActive(ACTIVE_COLOR)
      ;

    //adds a textfield to change the name 
    cp5.addTextfield("name1")

      //sets position, size
      //foreground, background and active color of the textfield
      .setPosition(width/2 + X_OFFSET_TEXTFIELD, height - Y_OFFSET_TEXTFIELD)
      .setSize(TEXTFIELD_WIDTH, TEXTFIELD_HEIGHT)
      .setColorForeground(FOREGROUND_COLOR)
      .setColorBackground(BACKGROUND_COLOR)
      .setColorActive(ACTIVE_COLOR)
      ;

    //places all the controller in the blue planet tab
    cp5.getController("speedOrbit1").moveTo("Blue Planet");
    cp5.getController("speedRotation1").moveTo("Blue Planet");
    cp5.getController("mass1").moveTo("Blue Planet");
    cp5.getController("radius1").moveTo("Blue Planet");
    cp5.getController("gravitationalField1").moveTo("Blue Planet");
    cp5.getController("name1").moveTo("Blue Planet");
  }

  //adds controllers to change parameters of the pink planet
  public void addControllerPinkPlanet() {

    //adds a knob to change the speed orbit
    cp5.addKnob("speedOrbit2")

      //sets the range, value, position, radius, number and length of tickmarks, 
      //drag direction, foreground, background and active color of the knob
      .setRange(MIN_ORBIT, MAX_ORBIT)
      .setValue(PINK_SPEED_ORBIT)
      .setPosition(width/2 - X_OFFSET_ORBIT_KNOB, height - Y_OFFSET_ORBIT_KNOB)
      .setRadius(KNOB_SIZE)
      .setNumberOfTickMarks(NUM_TICKMARKS)
      .setTickMarkLength(KNOB_TICKMARKS_LENGTH)
      .setDragDirection(Knob.HORIZONTAL)
      .setColorForeground(FOREGROUND_COLOR)
      .setColorBackground(BACKGROUND_COLOR)
      .setColorActive(ACTIVE_COLOR)
      ;

    //adds a knob to change the rotation 
    cp5.addKnob("speedRotation2")

      //sets the range, value, position, radius, number and length of tickmarks, 
      //drag direction, foreground, background and active color of the knob
      .setRange(MIN_ROTATION, MAX_ROTATION)
      .shuffle()
      .setPosition(width/2 - X_OFFSET_ROTATION_KNOB, height - Y_OFFSET_ROTATION_KNOB)
      .setRadius(KNOB_SIZE)
      .setNumberOfTickMarks(NUM_TICKMARKS)
      .setTickMarkLength(KNOB_TICKMARKS_LENGTH)
      .setDragDirection(Knob.HORIZONTAL)
      .setColorForeground(FOREGROUND_COLOR)
      .setColorBackground(BACKGROUND_COLOR)
      .setColorActive(ACTIVE_COLOR)
      ;

    //adds a slider to change the mass
    cp5.addSlider("mass2")

      //sets the range, value, size, position,  number  of tickmarks, 
      //foreground, background and active color of the slider
      .setRange(PINK_MASS - 1, PINK_MASS + 1)
      .setValue(PINK_MASS)
      .setSize(HORIZONTAL_SLIDER_WIDTH, HORIZONTAL_SLIDER_HEIGHT)
      .setPosition(width/2 - X_OFFSET_MASS_SLIDER, height - Y_OFFSET_MASS_SLIDER)
      .setColorForeground(FOREGROUND_COLOR)
      .setColorBackground(BACKGROUND_COLOR)
      .setColorActive(ACTIVE_COLOR)
      .setNumberOfTickMarks(NUM_SLIDER_TICKMARKS)
      ;

    //adds a slider to change the radius
    cp5.addSlider("radius2")

      //sets the range, value, size, position, 
      //foreground, background and active color of the slider
      .setRange(MIN_RADIUS, MAX_RADIUS)
      .setValue(PINK_RADIUS)
      .setSize(HORIZONTAL_SLIDER_WIDTH, HORIZONTAL_SLIDER_HEIGHT)
      .setPosition(width/2 - X_OFFSET_RADIUS_SLIDER, height - Y_OFFSET_RADIUS_SLIDER)
      .setColorForeground(FOREGROUND_COLOR)
      .setColorBackground(BACKGROUND_COLOR)
      .setColorActive(ACTIVE_COLOR)
      ;

    //adds a slider to change the gravitational field
    cp5.addSlider("gravitationalField2") 

      //sets the range, value, size, position, 
      //foreground, background and active color of the slider
      .setRange(MIN_GRAVITATION, MAX_GRAVITATION)
      .setValue(PINK_GRAVITATION)
      .setSize(VERTICAL_SLIDER_WIDTH, VERTICAL_SLIDER_HEIGHT)
      .setPosition(width/2 + X_OFFSET_GRAVITATION_SLIDER, height - Y_OFFSET_GRAVITATION_SLIDER)
      .setColorForeground(FOREGROUND_COLOR)
      .setColorBackground(BACKGROUND_COLOR)
      .setColorActive(ACTIVE_COLOR)
      ;

    //adds a textfield to change the name 
    cp5.addTextfield("name2")

      //sets position, size
      //foreground, background and active color of the textfield
      .setPosition(width/2 + X_OFFSET_TEXTFIELD, height - Y_OFFSET_TEXTFIELD)
      .setSize(TEXTFIELD_WIDTH, TEXTFIELD_HEIGHT)
      .setColorForeground(FOREGROUND_COLOR)
      .setColorBackground(BACKGROUND_COLOR)
      .setColorActive(ACTIVE_COLOR)
      ;

    //places all the controller in the pink planet tab
    cp5.getController("speedOrbit2").moveTo("Pink Planet");
    cp5.getController("speedRotation2").moveTo("Pink Planet");
    cp5.getController("mass2").moveTo("Pink Planet");
    cp5.getController("radius2").moveTo("Pink Planet");
    cp5.getController("gravitationalField2").moveTo("Pink Planet");
    cp5.getController("name2").moveTo("Pink Planet");
  }


  //adds controllers to change parameters of the green planet
  public void addControllerGreenPlanet() {

    //adds a knob to change the speed orbit
    cp5.addKnob("speedOrbit3")

      //sets the range, value, position, radius, number and length of tickmarks, 
      //drag direction, foreground, background and active color of the knob
      .setRange(MIN_ORBIT, MAX_ORBIT)
      .setValue(GREEN_SPEED_ORBIT)
      .setPosition(width/2 - X_OFFSET_ORBIT_KNOB, height - Y_OFFSET_ORBIT_KNOB)
      .setRadius(KNOB_SIZE)
      .setNumberOfTickMarks(NUM_TICKMARKS)
      .setTickMarkLength(KNOB_TICKMARKS_LENGTH)
      .setDragDirection(Knob.HORIZONTAL)
      .setColorForeground(FOREGROUND_COLOR)
      .setColorBackground(BACKGROUND_COLOR)
      .setColorActive(ACTIVE_COLOR)
      ;

    //adds a knob to change the rotation 
    cp5.addKnob("speedRotation3")

      //sets the range, value, position, radius, number and length of tickmarks, 
      //drag direction, foreground, background and active color of the knob 
      .setRange(MIN_ROTATION, MAX_ROTATION)
      .shuffle()
      .setPosition(width/2 - X_OFFSET_ROTATION_KNOB, height - Y_OFFSET_ROTATION_KNOB)
      .setRadius(KNOB_SIZE)
      .setNumberOfTickMarks(NUM_TICKMARKS)
      .setTickMarkLength(KNOB_TICKMARKS_LENGTH)
      .setDragDirection(Knob.HORIZONTAL)
      .setColorForeground(FOREGROUND_COLOR)
      .setColorBackground(BACKGROUND_COLOR)
      .setColorActive(ACTIVE_COLOR)
      ;

    //adds a slider to change the mass
    cp5.addSlider("mass3")

      //sets the range, value, size, position,  number  of tickmarks, 
      //foreground, background and active color of the slider
      .setRange(GREEN_MASS - 1, GREEN_MASS + 1)
      .setValue(GREEN_MASS)
      .setSize(HORIZONTAL_SLIDER_WIDTH, HORIZONTAL_SLIDER_HEIGHT)
      .setPosition(width/2 - X_OFFSET_MASS_SLIDER, height - Y_OFFSET_MASS_SLIDER)
      .setColorForeground(FOREGROUND_COLOR)
      .setColorBackground(BACKGROUND_COLOR)
      .setColorActive(ACTIVE_COLOR)
      .setNumberOfTickMarks(NUM_SLIDER_TICKMARKS)
      ;

    //adds a slider to change the radius
    cp5.addSlider("radius3")

      //sets the range, value, size, position, 
      //foreground, background and active color of the slider
      .setRange(MIN_RADIUS, MAX_RADIUS)
      .setValue(GREEN_RADIUS)
      .setSize(HORIZONTAL_SLIDER_WIDTH, HORIZONTAL_SLIDER_HEIGHT)
      .setPosition(width/2 - X_OFFSET_RADIUS_SLIDER, height - Y_OFFSET_RADIUS_SLIDER)
      .setColorForeground(FOREGROUND_COLOR)
      .setColorBackground(BACKGROUND_COLOR)
      .setColorActive(ACTIVE_COLOR)
      ;

    //adds a slider to change the gravitational field
    cp5.addSlider("gravitationalField3") 

      //sets the range, value, size, position, 
      //foreground, background and active color of the slider
      .setRange(MIN_GRAVITATION, MAX_GRAVITATION)
      .setValue(GREEN_GRAVITATION)
      .setSize(VERTICAL_SLIDER_WIDTH, VERTICAL_SLIDER_HEIGHT)
      .setPosition(width/2 + X_OFFSET_GRAVITATION_SLIDER, height - Y_OFFSET_GRAVITATION_SLIDER)
      .setColorForeground(FOREGROUND_COLOR)
      .setColorBackground(BACKGROUND_COLOR)
      .setColorActive(ACTIVE_COLOR)
      ;

    //adds a textfield to change the name 
    cp5.addTextfield("name3")

      //sets position, size
      //foreground, background and active color of the textfield
      .setPosition(width/2 + X_OFFSET_TEXTFIELD, height - Y_OFFSET_TEXTFIELD)
      .setSize(TEXTFIELD_WIDTH, TEXTFIELD_HEIGHT)
      .setColorForeground(FOREGROUND_COLOR)
      .setColorBackground(BACKGROUND_COLOR)
      .setColorActive(ACTIVE_COLOR)
      ;

    //places all the controller in the green planet tab
    cp5.getController("speedOrbit3").moveTo("Green Planet");
    cp5.getController("speedRotation3").moveTo("Green Planet");
    cp5.getController("mass3").moveTo("Green Planet");
    cp5.getController("radius3").moveTo("Green Planet");
    cp5.getController("gravitationalField3").moveTo("Green Planet");
    cp5.getController("name3").moveTo("Green Planet");
  }

  //adds controllers to change parameters of the purple planet
  public void addControllerPurplePlanet() {

    //adds a knob to change the speed orbit
    cp5.addKnob("speedOrbit4")

      //sets the range, value, position, radius, number and length of tickmarks, 
      //drag direction, foreground, background and active color of the knob
      .setRange(MIN_ORBIT, MAX_ORBIT)
      .setValue(PURPLE_SPEED_ORBIT)
      .setPosition(width/2 - X_OFFSET_ORBIT_KNOB, height - Y_OFFSET_ORBIT_KNOB)
      .setRadius(KNOB_SIZE)
      .setNumberOfTickMarks(NUM_TICKMARKS)
      .setTickMarkLength(KNOB_TICKMARKS_LENGTH)
      .setDragDirection(Knob.HORIZONTAL)
      .setColorForeground(FOREGROUND_COLOR)
      .setColorBackground(BACKGROUND_COLOR)
      .setColorActive(ACTIVE_COLOR)
      ;

    //adds a knob to change the rotation 
    cp5.addKnob("speedRotation4")

      //sets the range, value, position, radius, number and length of tickmarks, 
      //drag direction, foreground, background and active color of the knob
      .setRange(MIN_ROTATION, MAX_ROTATION)
      .shuffle()
      .setPosition(width/2 - X_OFFSET_ROTATION_KNOB, height - Y_OFFSET_ROTATION_KNOB)
      .setRadius(KNOB_SIZE)
      .setNumberOfTickMarks(NUM_TICKMARKS)
      .setTickMarkLength(KNOB_TICKMARKS_LENGTH)
      .setDragDirection(Knob.HORIZONTAL)
      .setColorForeground(FOREGROUND_COLOR)
      .setColorBackground(BACKGROUND_COLOR)
      .setColorActive(ACTIVE_COLOR)
      ;

    //adds a slider to change the mass
    cp5.addSlider("mass4")

      //sets the range, value, size, position,  number  of tickmarks, 
      //foreground, background and active color of the slider
      .setRange(PURPLE_MASS - 1, PURPLE_MASS + 1)
      .setValue(PURPLE_MASS)
      .setSize(HORIZONTAL_SLIDER_WIDTH, HORIZONTAL_SLIDER_HEIGHT)
      .setPosition(width/2 - X_OFFSET_MASS_SLIDER, height - Y_OFFSET_MASS_SLIDER)
      .setColorForeground(FOREGROUND_COLOR)
      .setColorBackground(BACKGROUND_COLOR)
      .setColorActive(ACTIVE_COLOR)
      .setNumberOfTickMarks(NUM_SLIDER_TICKMARKS)
      ;

    //adds a slider to change the radius
    cp5.addSlider("radius4")

      //sets the range, value, size, position, 
      //foreground, background and active color of the slider
      .setRange(MIN_RADIUS, MAX_RADIUS)
      .setValue(PURPLE_RADIUS)
      .setSize(HORIZONTAL_SLIDER_WIDTH, HORIZONTAL_SLIDER_HEIGHT)
      .setPosition(width/2 - X_OFFSET_RADIUS_SLIDER, height - Y_OFFSET_RADIUS_SLIDER)
      .setColorForeground(FOREGROUND_COLOR)
      .setColorBackground(BACKGROUND_COLOR)
      .setColorActive(ACTIVE_COLOR)
      ;

    //adds a slider to change the gravitational field
    cp5.addSlider("gravitationalField4") 

      //sets the range, value, size, position, 
      //foreground, background and active color of the slider
      .setRange(MIN_GRAVITATION, MAX_GRAVITATION)
      .setValue(PURPLE_GRAVITATION)
      .setSize(VERTICAL_SLIDER_WIDTH, VERTICAL_SLIDER_HEIGHT)
      .setPosition(width/2 + X_OFFSET_GRAVITATION_SLIDER, height - Y_OFFSET_GRAVITATION_SLIDER)
      .setColorForeground(FOREGROUND_COLOR)
      .setColorBackground(BACKGROUND_COLOR)
      .setColorActive(ACTIVE_COLOR)
      ;

    //adds a textfield to change the name
    cp5.addTextfield("name4")

      //sets position, size
      //foreground, background and active color of the textfield
      .setPosition(width/2 + X_OFFSET_TEXTFIELD, height - Y_OFFSET_TEXTFIELD)
      .setSize(TEXTFIELD_WIDTH, TEXTFIELD_HEIGHT)
      .setColorForeground(FOREGROUND_COLOR)
      .setColorBackground(BACKGROUND_COLOR)
      .setColorActive(ACTIVE_COLOR)
      ;

    //places all the controller in the purple planet tab
    cp5.getController("speedOrbit4").moveTo("Purple Planet");
    cp5.getController("speedRotation4").moveTo("Purple Planet");
    cp5.getController("mass4").moveTo("Purple Planet");
    cp5.getController("radius4").moveTo("Purple Planet");
    cp5.getController("gravitationalField4").moveTo("Purple Planet");
    cp5.getController("name4").moveTo("Purple Planet");
  }

  //adds controllers to change parameters of the red planet
  public void addControllerRedPlanet() {

    //adds a knob to change the speed orbit
    cp5.addKnob("speedOrbit5")

      //sets the range, value, position, radius, number and length of tickmarks, 
      //drag direction, foreground, background and active color of the knob
      .setRange(MIN_ORBIT, MAX_ORBIT)
      .setValue(RED_SPEED_ORBIT)
      .setPosition(width/2 - X_OFFSET_ORBIT_KNOB, height - Y_OFFSET_ORBIT_KNOB)
      .setRadius(KNOB_SIZE)
      .setNumberOfTickMarks(NUM_TICKMARKS)
      .setTickMarkLength(KNOB_TICKMARKS_LENGTH)
      .setDragDirection(Knob.HORIZONTAL)
      .setColorForeground(FOREGROUND_COLOR)
      .setColorBackground(BACKGROUND_COLOR)
      .setColorActive(ACTIVE_COLOR)
      ;

    //adds a knob to change the rotation 
    cp5.addKnob("speedRotation5")

      //sets the range, value, position, radius, number and length of tickmarks, 
      //drag direction, foreground, background and active color of the knob
      .setRange(MIN_ROTATION, MAX_ROTATION)
      .shuffle()
      .setPosition(width/2 - X_OFFSET_ROTATION_KNOB, height - Y_OFFSET_ROTATION_KNOB)
      .setRadius(KNOB_SIZE)
      .setNumberOfTickMarks(NUM_TICKMARKS)
      .setTickMarkLength(KNOB_TICKMARKS_LENGTH)
      .setDragDirection(Knob.HORIZONTAL)
      .setColorForeground(FOREGROUND_COLOR)
      .setColorBackground(BACKGROUND_COLOR)
      .setColorActive(ACTIVE_COLOR)
      ;

    //adds a slider to change the mass
    cp5.addSlider("mass5")

      //sets the range, value, size, position,  number  of tickmarks, 
      //foreground, background and active color of the slider
      .setRange(RED_MASS - 1, RED_MASS + 1)
      .setValue(RED_MASS)
      .setSize(HORIZONTAL_SLIDER_WIDTH, HORIZONTAL_SLIDER_HEIGHT)
      .setPosition(width/2 - X_OFFSET_MASS_SLIDER, height - Y_OFFSET_MASS_SLIDER)
      .setColorForeground(FOREGROUND_COLOR)
      .setColorBackground(BACKGROUND_COLOR)
      .setColorActive(ACTIVE_COLOR)
      .setNumberOfTickMarks(NUM_SLIDER_TICKMARKS)
      ;

    //adds a slider to change the radius
    cp5.addSlider("radius5")

      //sets the range, value, size, position, 
      //foreground, background and active color of the slider
      .setRange(MIN_RADIUS, MAX_RADIUS)
      .setValue(RED_RADIUS)
      .setSize(HORIZONTAL_SLIDER_WIDTH, HORIZONTAL_SLIDER_HEIGHT)
      .setPosition(width/2 - X_OFFSET_RADIUS_SLIDER, height - Y_OFFSET_RADIUS_SLIDER)
      .setColorForeground(FOREGROUND_COLOR)
      .setColorBackground(BACKGROUND_COLOR)
      .setColorActive(ACTIVE_COLOR)
      ;

    //adds a slider to change the gravitational field
    cp5.addSlider("gravitationalField5") 

      //sets the range, value, size, position, 
      //foreground, background and active color of the slider
      .setRange(MIN_GRAVITATION, MAX_GRAVITATION)
      .setValue(RED_GRAVITATION)
      .setSize(VERTICAL_SLIDER_WIDTH, VERTICAL_SLIDER_HEIGHT)
      .setPosition(width/2 + X_OFFSET_GRAVITATION_SLIDER, height - Y_OFFSET_GRAVITATION_SLIDER)
      .setColorForeground(FOREGROUND_COLOR)
      .setColorBackground(BACKGROUND_COLOR)
      .setColorActive(ACTIVE_COLOR)
      ;

    //adds a textfield to change the name 
    cp5.addTextfield("name5")

      //sets position, size
      //foreground, background and active color of the textfield
      .setPosition(width/2 + X_OFFSET_TEXTFIELD, height - Y_OFFSET_TEXTFIELD)
      .setSize(TEXTFIELD_WIDTH, TEXTFIELD_HEIGHT)
      .setColorForeground(FOREGROUND_COLOR)
      .setColorBackground(BACKGROUND_COLOR)
      .setColorActive(ACTIVE_COLOR)
      ;

    //places all the controller in the red planet tab
    cp5.getController("speedOrbit5").moveTo("Red Planet");
    cp5.getController("speedRotation5").moveTo("Red Planet");
    cp5.getController("mass5").moveTo("Red Planet");
    cp5.getController("radius5").moveTo("Red Planet");
    cp5.getController("gravitationalField5").moveTo("Red Planet");
    cp5.getController("name5").moveTo("Red Planet");
  }

  //adds controllers to change parameters of the blue planet
  public void addControllerOrangePlanet() {

    //adds a knob to change the speed orbit
    cp5.addKnob("speedOrbit6")

      //sets the range, value, position, radius, number and length of tickmarks, 
      //drag direction, foreground, background and active color of the knob
      .setRange(MIN_ORBIT, MAX_ORBIT)
      .setValue(ORANGE_SPEED_ORBIT)
      .setPosition(width/2 - X_OFFSET_ORBIT_KNOB, height - Y_OFFSET_ORBIT_KNOB)
      .setRadius(KNOB_SIZE)
      .setNumberOfTickMarks(NUM_TICKMARKS)
      .setTickMarkLength(KNOB_TICKMARKS_LENGTH)
      .setDragDirection(Knob.HORIZONTAL)
      .setColorForeground(FOREGROUND_COLOR)
      .setColorBackground(BACKGROUND_COLOR)
      .setColorActive(ACTIVE_COLOR)
      ;

    //adds a knob to change the rotation 
    cp5.addKnob("speedRotation6")

      //sets the range, value, position, radius, number and length of tickmarks, 
      //drag direction, foreground, background and active color of the knob
      .setRange(MIN_ROTATION, MAX_ROTATION)
      .shuffle()
      .setPosition(width/2 - X_OFFSET_ROTATION_KNOB, height - Y_OFFSET_ROTATION_KNOB)
      .setRadius(KNOB_SIZE)
      .setNumberOfTickMarks(NUM_TICKMARKS)
      .setTickMarkLength(KNOB_TICKMARKS_LENGTH)
      .setDragDirection(Knob.HORIZONTAL)
      .setColorForeground(FOREGROUND_COLOR)
      .setColorBackground(BACKGROUND_COLOR)
      .setColorActive(ACTIVE_COLOR)
      ;

    //adds a slider to change the mass
    cp5.addSlider("mass6")

      //sets the range, value, size, position,  number  of tickmarks, 
      //foreground, background and active color of the slider
      .setRange(ORANGE_MASS - 1, ORANGE_MASS + 1)
      .setValue(ORANGE_MASS)
      .setSize(HORIZONTAL_SLIDER_WIDTH, HORIZONTAL_SLIDER_HEIGHT)
      .setPosition(width/2 - X_OFFSET_MASS_SLIDER, height - Y_OFFSET_MASS_SLIDER)
      .setColorForeground(FOREGROUND_COLOR)
      .setColorBackground(BACKGROUND_COLOR)
      .setColorActive(ACTIVE_COLOR)
      .setNumberOfTickMarks(NUM_SLIDER_TICKMARKS)
      ;

    //adds a slider to change the radius
    cp5.addSlider("radius6")

      //sets the range, value, size, position, 
      //foreground, background and active color of the slider
      .setRange(MIN_RADIUS, MAX_RADIUS)
      .setValue(ORANGE_RADIUS)
      .setSize(HORIZONTAL_SLIDER_WIDTH, HORIZONTAL_SLIDER_HEIGHT)
      .setPosition(width/2 - X_OFFSET_RADIUS_SLIDER, height - Y_OFFSET_RADIUS_SLIDER)
      .setColorForeground(FOREGROUND_COLOR)
      .setColorBackground(BACKGROUND_COLOR)
      .setColorActive(ACTIVE_COLOR)
      ;

    //adds a slider to change the gravitational field
    cp5.addSlider("gravitationalField6") 

      //sets the range, value, size, position, 
      //foreground, background and active color of the slider
      .setRange(MIN_GRAVITATION, MAX_GRAVITATION)
      .setValue(ORANGE_GRAVITATION)
      .setSize(VERTICAL_SLIDER_WIDTH, VERTICAL_SLIDER_HEIGHT)
      .setPosition(width/2 + X_OFFSET_GRAVITATION_SLIDER, height - Y_OFFSET_GRAVITATION_SLIDER)
      .setColorForeground(FOREGROUND_COLOR)
      .setColorBackground(BACKGROUND_COLOR)
      .setColorActive(ACTIVE_COLOR)
      ;

    //adds a textfield to change the name 
    cp5.addTextfield("name6")

      //sets position, size
      //foreground, background and active color of the textfield
      .setPosition(width/2 + X_OFFSET_TEXTFIELD, height - Y_OFFSET_TEXTFIELD)
      .setSize(TEXTFIELD_WIDTH, TEXTFIELD_HEIGHT)
      .setColorForeground(FOREGROUND_COLOR)
      .setColorBackground(BACKGROUND_COLOR)
      .setColorActive(ACTIVE_COLOR)
      ;

    //places all the controller in the blue planet tab
    cp5.getController("speedOrbit6").moveTo("Orange Planet");
    cp5.getController("speedRotation6").moveTo("Orange Planet");
    cp5.getController("mass6").moveTo("Orange Planet");
    cp5.getController("radius6").moveTo("Orange Planet");
    cp5.getController("gravitationalField6").moveTo("Orange Planet");
    cp5.getController("name6").moveTo("Orange Planet");
  }

  //this function displays the cockpit 
  public void displayCockpit() {
    image(cockpit, 0, 0, width, height);
  }

  //this function displays the position of the cockpit
  public void spaceshipPosition(float cameraXLocation, float cameraZLocation) {

    //fills the text with white
    fill(255);

    //sets the font and size of the text
    textFont(font);
    textSize(12);

    //displays the text
    text("POSITION", width/2 + 100, height - 150);
    text("X: " + cameraXLocation, width/2 + 100, height - 130);
    text("Z: " + cameraZLocation, width/2 + 100, height - 110);

    //sets no fill and a stroke to blue
    noFill();
    stroke(58, 167, 242);

    //displays a rect around the text
    rectMode(CENTER);
    rect(width/2 + 150, height - 135, 120, 70);
  }

  //this function calls the keyPressed function of the different planets
  public void keyPressed() {

    if (planet == 1) {

      //calls the keyPressed function of the planet 1 (blue planet)
      universe.celestialObjects.get(1).keyPressed();
    } else if (planet == 2) {

      //calls the keyPressed function of the planet 2 (pink planet)
      universe.celestialObjects.get(2).keyPressed();
    } else if (planet == 3) {

      //calls the keyPressed function of the planet 3 (green planet)
      universe.celestialObjects.get(3).keyPressed();
    } else if (planet == 4) {

      //calls the keyPressed function of the planet 4 (purple planet)
      universe.celestialObjects.get(4).keyPressed();
    } else if (planet == 5) {

      //calls the keyPressed function of the planet 5 (red planet)
      universe.celestialObjects.get(5).keyPressed();
    } else if (planet == 6) {

      //calls the keyPressed function of the planet 6 (orange planet)
      universe.celestialObjects.get(6).keyPressed();
    }
  }
}

//***** End of the ControlPanel class *****//


//********** These functions need to be outide an inner classs, even if it should be in the ControlPanel **************//
//********** but otherwise the ControlP5 doesn't work **************//

//---------- Functions to set new parameters for the blue planet ----------------///

//sets a new speed orbit
public void speedOrbit1(int newSpeedOrbit1) {
  universe.celestialObjects.get(1).setSpeedOrbit(newSpeedOrbit1);
}

//sets a new speed rotation
public void speedRotation1(int newSpeedRotation1) {
  universe.celestialObjects.get(1).setSpeedRotation(newSpeedRotation1);
}

//sets new mass
public void mass1 (int newMass1) {
  universe.celestialObjects.get(1).setMass(newMass1);
}

//sets new mass
public void radius1 (int newRadius1) {
  universe.celestialObjects.get(1).setRadius(newRadius1);
}

//sets new gravitational field
public void gravitationalField1(int newGravitationalField1) {
  universe.celestialObjects.get(1).setGravitationalField(newGravitationalField1);
}

//sets new name
public void name1(String newName1) {
  universe.celestialObjects.get(1).setPlanetName(newName1);
}

//---------------------------------------------------------------------------//

//---------- Functions to set new parameters for the pink planet ----------------///

//sets a new speed orbit
public void speedOrbit2(int newSpeedOrbit2) {
  universe.celestialObjects.get(2).setSpeedOrbit(newSpeedOrbit2);
}

//sets a new speed rotation
public void speedRotation2(int newSpeedRotation2) {
  universe.celestialObjects.get(2).setSpeedRotation(newSpeedRotation2);
}

//sets new mass
public void mass2 (int newMass2) {
  universe.celestialObjects.get(2).setMass(newMass2);
}

//sets new radius
public void radius2 (int newRadius2) {
  universe.celestialObjects.get(2).setRadius(newRadius2);
}

//sets new gravitational field
public void gravitationalField2(int newGravitationalField2) {
  universe.celestialObjects.get(2).setGravitationalField(newGravitationalField2);
}

//sets new name
public void name2(String newName2) {
  universe.celestialObjects.get(2).setPlanetName(newName2);
}

//---------------------------------------------------------------------------//

//---------- Functions to set new parameters for the green planet ----------------///

//sets a new speed orbit
public void speedOrbit3(int newSpeedOrbit3) {
  universe.celestialObjects.get(3).setSpeedOrbit(newSpeedOrbit3);
}

//sets a new speed rotation
public void speedRotation3(int newSpeedRotation3) {
  universe.celestialObjects.get(3).setSpeedRotation(newSpeedRotation3);
}

//sets new mass
public void mass3 (int newMass3) {
  universe.celestialObjects.get(3).setMass(newMass3);
}

//sets new radius
public void radius3 (int newRadius3) {
  universe.celestialObjects.get(3).setRadius(newRadius3);
}

//sets new gravitational field
public void gravitationalField3(int newGravitationalField3) {
  universe.celestialObjects.get(3).setGravitationalField(newGravitationalField3);
}

//sets new name
public void name3(String newName3) {
  universe.celestialObjects.get(3).setPlanetName(newName3);
}

//---------------------------------------------------------------------------//

//---------- Functions to set new parameters for the purple planet ----------------///

//sets a new speed orbit
public void speedOrbit4(int newSpeedOrbit4) {
  universe.celestialObjects.get(4).setSpeedOrbit(newSpeedOrbit4);
}

//sets a new speed rotation
public void speedRotation4(int newSpeedRotation4) {
  universe.celestialObjects.get(4).setSpeedRotation(newSpeedRotation4);
}

//sets new mass
public void mass4 (int newMass4) {
  universe.celestialObjects.get(4).setMass(newMass4);
}

//sets new radius
public void radius4 (int newRadius4) {
  universe.celestialObjects.get(4).setRadius(newRadius4);
}

//sets new gravitational field
public void gravitationalField4(int newGravitationalField4) {
  universe.celestialObjects.get(4).setGravitationalField(newGravitationalField4);
}

//sets new name
public void name4(String newName4) {
  universe.celestialObjects.get(4).setPlanetName(newName4);
}

//---------------------------------------------------------------------------//

//---------- Functions to set new parameters for the red planet ----------------//

//sets a new speed orbit
public void speedOrbit5(int newSpeedOrbit5) {
  universe.celestialObjects.get(5).setSpeedOrbit(newSpeedOrbit5);
}

//sets a new speed rotation
public void speedRotation5(int newSpeedRotation5) {
  universe.celestialObjects.get(5).setSpeedRotation(newSpeedRotation5);
}

//sets new mass
public void mass5 (int newMass5) {
  universe.celestialObjects.get(5).setMass(newMass5);
}

//sets new radius
public void radius5 (int newRadius5) {
  universe.celestialObjects.get(5).setRadius(newRadius5);
}

//sets new gravitational field
public void gravitationalField5(int newGravitationalField5) {
  universe.celestialObjects.get(5).setGravitationalField(newGravitationalField5);
}

//sets new name
public void name5(String newName5) {
  universe.celestialObjects.get(5).setPlanetName(newName5);
}

//---------------------------------------------------------------------------//

//---------- Functions to set new parameters for the orange planet ----------------//

//sets a new speed orbit
public void speedOrbit6(int newSpeedOrbit6) {
  universe.celestialObjects.get(6).setSpeedOrbit(newSpeedOrbit6);
}

//sets a new speed rotation
public void speedRotation6(int newSpeedRotation6) {
  universe.celestialObjects.get(6).setSpeedRotation(newSpeedRotation6);
}

//sets new mass
public void mass6 (int newMass6) {
  universe.celestialObjects.get(6).setMass(newMass6);
}

//sets new radius
public void radius6 (int newRadius6) {
  universe.celestialObjects.get(6).setRadius(newRadius6);
}

//sets new gravitational field
public void gravitationalField6(int newGravitationalField6) {
  universe.celestialObjects.get(6).setGravitationalField(newGravitationalField6);
}

//sets new name
public void name6(String newName6) {
  universe.celestialObjects.get(6).setPlanetName(newName6);
}

//---------------------------------------------------------------------------//


//tells to which planet the user add new particles
int planet = 0;

//sets a new value to planet
public void blue_Particles(int blue) {
  planet = blue;
}

//sets a new value to planet
public void pink_Particles(int pink) {
  planet = pink;
}

//sets a new value to planet
public void green_Particles(int green) {
  planet = green;
}

//sets a new value to planet
public void purple_Particles(int purple) {
  planet = purple;
}

//sets a new value to planet
public void red_Particles(int red) {
  planet = red;
}

//sets a new value to planet
public void orange_Particles(int orange) {
  planet = orange;
}

//sets a new state to displayNames 
public void displayNames(boolean displayNames_) {

  //for each celestial objects
  for (int i = 0; i < universe.celestialObjects.size(); i++) {

    //changes the state of the displayPlanetName boolean
    CelestialObject co = universe.celestialObjects.get(i);
    co.setStateDisplayPlanetNames(displayNames_);
  }
}
/**
 * A class describing a physical particle in a 3D space. Particles have a location (x,y, z), a velocity, a maxSpeed,
 * a maxForce,  an acceleration and a mass. 
 *  The particle can be attracted or pushed away from the planets
 */

class Particle {

  //the location, the velocity and the acceleration of the particle
  PVector location;
  PVector velocity;
  PVector acceleration;

  //the mass of the particle
  float mass;

  //the maximum speed of the particle
  float maxSpeed = 2; 

  //the maximum force that can be applied on the particles
  float maxForce = 1;

  //Constructor. ParticleParent can be created with a mass, and a x, y, z location
  Particle(float mass_, float x, float y, float z) {

    //asigns values to data and assign new Pvector to data
    acceleration = new PVector(0, 0, 0);
    velocity = PVector.random3D();
    location = new PVector(x, y, z);
    mass = mass_;
  }

  //this function applies a certain force on the particle
  public void applyForce(PVector force) {

    //gets a copy of the force vector
    PVector f = force.get();

    //divides the force by the mass
    f.div(mass);   

    //ad the force to the acceleration
    acceleration.add(f);
  }

  //this function call the update() and display() function at the same time
  public void run() {
    update();
    display();
  }

  // Method to update the position of the particle
  public void update() {

    //acceleration modifies the velocity and velocity modifies the location of the Particle
    velocity.add(acceleration);
    location.add(velocity);

    //clears the accelareation each time the update() function is called
    acceleration.mult(0);
  }

  // This function displays the particle
  public void display() {

    //sets no stroke 
    noStroke();

    //translates the location of the particle according to location.x, location.y and location.z and draw the sphere particle
    pushMatrix();
    translate(location.x, location.y, location.z);
    sphere(mass*2);
    popMatrix();
  }

  //A function that seeks the particle through a target(the planet)
  public void seek(PVector target) {

    //a vector pointing from the particle location to the target
    PVector desired = PVector.sub(target, location);  

    //distance between the particle and the target
    float distance = desired.mag();

    //set the magnitude to maxSpeed
    desired.setMag(maxSpeed);

    // Steering = Desired minus Velocity
    PVector steer = PVector.sub(desired, velocity);

    // Limits to maximum steering force
    steer.limit(maxForce);  

    //applies the steering force
    applyForce(steer);
  }

  //this function makes the partcle go away of a target (the planet)
  public void goAway(PVector target, float planetMass) {

    //specifies how close is too close of the target
    float desiredSeparation = planetMass + 10 ;

    //distance between the particle and the target
    float distance = PVector.dist(location, target);

    //if distance is smaller than the desired separation
    if (distance < desiredSeparation) {

      //a vector pointing away from the planet location
      PVector difference = PVector.sub(location, target);

      //sets the magnitude to maxSpeed
      difference.setMag(maxSpeed);

      // Steering = Desired minus Velocity
      PVector steer = PVector.sub(difference, velocity);

      //limits to maximum steering force
      steer.limit(maxForce);

      //applies the force
      applyForce(steer);
    }
  }
}
/**
 * A class to describe a group of Particles. An ArrayList is used to manage the list of Particles.
 * The particle system has a origin point and the gravitation field of the planet
 */

class ParticleSystem {

  // An arraylist for all the particles.
  ArrayList<Particle> particles;

  // An origin point for where particles are birthed.
  PVector origin;

  //gravitation field of the planet
  float gravitationalField;

  //constructor with the origin location
  ParticleSystem(PVector origin_) {

    // Initializes the arraylist.
    particles = new ArrayList<Particle>();

    // Stores the origin point
    origin = origin_.get();

    //creates 50 particles
    for (int i=0; i< 50; i++) {
      particles.add(createParticle());
    }
  }

  // This method is called at every step. Applies the forces on particles and updates them.
  public void run(PVector newOrigin, float planetMass, float gravitationalField) {

    //pass the origin parameter 
    origin = newOrigin;

    //calls the applySeeking functions
    applySeeking(planetMass, gravitationalField);

    //for every particles in the arraylist
    for (int i = particles.size()-1; i >= 0; i--) {

      //calls the run function
      Particle p = particles.get(i);
      p.run();
    }
  }

  //adds aparticle
  public void addParticle() {
    particles.add(createParticle());
  }

  // Creates and returns a new particle at a random position.
  //substract the origin and width/2 and height/2 to "cancel" the previous translate
  public Particle createParticle() {
    return new Particle(random(1, 6), random(width) - (origin.x + width/2), random(height) - (origin.y + height/2), 0);
  }

  // Applies seeking behavior for all the particles
  public void applySeeking(float mass, float gravitationalField) {

    //for each particles
    for (Particle p : particles) {

      //distance between the location of the particle and the planet
      PVector distance = PVector.sub(p.location, new PVector(0, 0, 0));

      //if the distance is greater than the planet gravitational field
      if (distance.mag() > gravitationalField) {

        //seeks toward the planet
        p.seek(new PVector(0, 0, 0));
      } else {      

        //go away of the planet
        p.goAway(new PVector(0, 0, 0), mass);
      }
    }
  }
}
/**
 * A subclass of CelestialObject describing a physical planet in a 3D space. The planet has an arrayList of systems, two angles, a speed orbit,
 * a speed rotation, a gravitational field, a radius and a specific particle color
 */
class Planet extends CelestialObject {

  //arraylist of systems
  ArrayList<ParticleSystem> systems;

  //angle the planet rotates around itself
  float angle2;

  //angle the planet rotates around the sun
  float angle;

  //the speed of the rotation around the sun
  float speedOrbit;

  //the speed of the rotation arount itself
  float speedRotation;

  //distance between the sun and the planet
  float radius;

  //gravitational field of the planet
  float gravitationalField;

  //color to fill the particle system
  int colorParticle;

  //the name of the planet
  String planetName;

  //tells if the planets names are displayed or not
  boolean displayPlanetNames = false;

  //Constructor. PlanetParent can be created with a x, y, z location, a size, a texture, color, 
  //radius, speed orbit, speed rotation, gravitational field and a name
  Planet(PVector location_, float size_, String textureFileName_, int colorParticle_, float radius_, float speedOrbit_, 
    float speedRotation_, float gravitationalField_, String planetName_) {

    //calls the contructor of the parent class
    super(location_, size_, textureFileName_);

    //Assign values to data and new PVector to data
    gravitationalField = gravitationalField_;
    colorParticle = colorParticle_;
    radius = radius_;
    speedOrbit = speedOrbit_;
    speedRotation = speedRotation_;
    planetName = planetName_;
    angle = 0;
    angle2 = 0;

    //creates the system arrayList
    systems = new ArrayList<ParticleSystem>();

    //adds a new system in the arraylist
    systems.add(new ParticleSystem(new PVector(location.x, location.y, location.z)));
  }

  //this function displays the planet
  public void display() {

    pushMatrix();

    //translates the location of the planet according to location.x, location.y and location.z and draw the sphere planet
    //need to have a different translate for the sun and planete, otherwise, the particle will be attracted to the sun...
    translate(location.x, location.y, location.z);

    //if displayPlanetNames is true
    if (displayPlanetNames == true) {

      //sets the fill, the font and the size of the text
      fill(35, 232, 174);
      textFont(font);
      textSize(100);

      //displays the name
      text(planetName, 0, -200, 0);
    }

    //for each particle systems
    for (ParticleSystem ps : systems) {

      //fills the particle system with the associated color and a random alpha channel
      fill(colorParticle, random(150, 255));

      //calls the run function
      ps.run(location, mass, gravitationalField);
    }

    //rotate the planet around itself
    rotateY(angle2);

    //sets no fill
    noFill();

    //calls the display function of the parent class
    super.display();
    popMatrix();
  }

  //this function updates the position of the system
  public void update() {

    //updates the angle at which the planet is rotating
    float angle = TWO_PI * millis()/speedOrbit;

    //sets the x and z components updated by the angle and multiply by the radius
    location.x = cos(angle) * radius;
    location.z = sin(angle) * radius;

    //updates the angle2
    angle2 += (speedRotation/100);
  }

  //sets a new speed orbit
  public void setSpeedOrbit(float newSpeedOrbit) {
    speedOrbit = newSpeedOrbit;
  }

  //sets a new speed rotation
  public void setSpeedRotation(float newSpeedRotation) {
    speedRotation = newSpeedRotation;
  }

  //sets a new radius
  public void setRadius(float newRadius) {
    radius = newRadius;
  }

  //sets a new gravitational field
  public void setGravitationalField(float newGravitationalField) {
    gravitationalField = newGravitationalField;
  }

  //sets a new planet name
  public void setPlanetName(String newPlanetName) {
    planetName = newPlanetName;
  }

  //sets a new state to the boolean displayPlanetNames
  public void setStateDisplayPlanetNames(boolean newState) {
    displayPlanetNames = newState;
  }

  //this function adds new particle systems to the arraylist systems 
  public void addParticleSystem(float mx, float my) { 

    //need to delete planetLocation and sunLocation since we translate it toward this and we want to come back to the orginal location
    systems.add(new ParticleSystem(new PVector(mx - (location.x + width/2), (my - (location.y + height/2)))));
  }

  //this function adds a new particle system when the key "+" is pressed
  public void keyPressed() {
    if (key == '+') {
      addParticleSystem(mouseX + random(-100, 100), mouseY + random(-100, 100));
    }
  }
}
// This class contains the start menu of the game. A image is given for the title of the game
class StartMenu {

  //instatiates the image for the title
  PImage title;
  
  //x position of the text
   final float X_POSITION = 100;

  //constructor.
  StartMenu() {

    //load title
    title = loadImage("title.png");
  }

  //displays the start menu
  public void display() {

    //sets the recmode to corner and the fill color to black
    rectMode(CORNER);
    fill(0);

    //draws a rectangle
    rect(0, 0, width, height);

    //displays the title
    image(title, 20, 0, width, 720);

    //sets the font, the size and the color of the text
    textFont(font);
    textSize(50);
    fill(10, 69, 237);

    //displays the text
    text("WELCOME ABOARD!", X_POSITION, height/2 - 70);

    //sets the font, the size and the color of the text
    fill(58, 167, 242);
    textSize(45);

    //displays the text
    text("YOUR MISSION :", X_POSITION, height/2 + 15);

    //sets the size of the text
    textSize(30);

    //displays the text
    text("-EXPLORE THE 3D WORLD", X_POSITION, height/2 + 80);
    text("-CUSTOMIZE THE PLANETS SYSTEM", X_POSITION, height/2 + 120);

    //sets the size of the text
    textSize(23);

    //displays the text
    text("TIP: BE CAREFUL, AVOID BEING STUCK INSIDE A PLANET ORBIT", X_POSITION, height/2 + 170);
    text("TIP 2: TRY TO PRESS '+' DURING YOUR EXPLORATION", X_POSITION, height/2 + 210);

    //sets the size of the text
    textSize(21);

    //fills and displays the text
    fill(10, 69, 237);
    text("PRESS \u2018S\u2019 TO ACCESS YOUR SPACESHIP", width/2 - 200, height - 120);
    
    //sets the textSize
    textSize(17);
    text("(NAVIGATE WITH THE ARROW KEYS)", width/2 - 150, height - 100);
  }
}
/**
 * A subclass of celestial object describing a physical sun in a 3D space. The sun has the same parameter as the celestial object
 */
class Sun extends CelestialObject {

  //Constructor. The sun can be created with a location, a mass and a texture
  Sun(PVector location_, float mass_, String textureFileName) {

    //calls the constructor of the parent class
    super(location_, mass_, textureFileName);
  }

  //this function displays the sun
  public void display() {

    //sets no stroke
    noStroke();

    //translates the location of the system according to location.x, lcoation.y and location.z 
    pushMatrix();
    translate(location.x, location.y, location.z);

    //calls the display function of the parent class
    super.display();
    popMatrix();
  }
}
/** 
 * A universe class that contains all the object of my universe (the celestial objects, particle systems, background) and a camera.
 * The camera allows the users to explore the universe.
 */

class Universe {

  //creates a PImage as the background
  PImage background;

  //arrayList of celestial object
  ArrayList<CelestialObject> celestialObjects;

  //an array of colors
  int[] colors;

  //delcares a camera
  Camera myCamera;

  //Constructor.
  Universe() {

    //instatiates the arrayList celestialObject
    celestialObjects = new ArrayList<CelestialObject>();

    //instantiates the colors array
    colors = new int[6];

    //instantiates the camera
    myCamera = new Camera();

    //loads background image
    //Image by Karissa(ex-astris1701)
    //artist authorizes the use of the image
    //http://fav.me/d48gc0f
    background = loadImage("background.jpg");

    //for each index in the array colors, assign a different colors

    //assigns blue
    colors[0] = 0xff0FEAF0;

    //assigns pink
    colors[1] = 0xffF00FA5;

    //assigns green
    colors[2] = 0xff59E813;

    //assigns purple
    colors[3] = 0xffAE11ED;

    //assigns red
    colors[4] = 0xffF20F0F;

    //assigns orange
    colors[5] = 0xffF2900F;

    //Instantiates the sun
    //Image of the sun by James Hasting-Trew
    //http://planetpixelemporium.com/venus.html
    //Artist authorizes the use of his image
    //Modified by Maelle Morin
    celestialObjects.add(new Sun(new PVector(0, 0, 0), 450, "sun.jpg"));

    //instantiates the 6 planets
    //Planet Names generated by this website http://fantasynamegenerators.com/planet_names.php#.VxUBQJPhCRu
    //The planet textures were done by David Bryan Roberson(avmorgan) and modified by Maelle Morin
    //All the image are under the Creative Commons Atribution-Share Alike 3.0 License
    //blue : http://fav.me/d5omtsl
    //pink: http://fav.me/d4z4auq
    //green: http://fav.me/d2x26i1
    //purple and orange: http://fav.me/d6aj028
    //red: http://fav.me/d2x26xy
    celestialObjects.add(new Planet(new PVector(0, 0, 0), 60, "blue.jpg", colors[0], 800, 20000, 20, 200, "BLUME"));   
    celestialObjects.add(new Planet(new PVector(0, 0, 0), 100, "pink.jpg", colors[1], 1300, 28000, 20, 200, "FUSTRYRIA"));
    celestialObjects.add(new Planet(new PVector(0, 0, 0), 75, "green.jpg", colors[2], 2000, 45000, 20, 100, "GRERTH"));
    celestialObjects.add(new Planet(new PVector(0, 0, 0), 185, "purple.jpg", colors[3], 3000, 21000, 20, 300, "PUANOPE"));
    celestialObjects.add(new Planet(new PVector(0, 0, 0), 40, "red.jpg", colors[4], 3600, 30000, 20, 100, "RUBLAPUS"));
    celestialObjects.add(new Planet(new PVector(0, 0, 0), 90, "orange.jpg", colors[5], 4000, 60000, 20, 200, "OSMIANUS"));
  }

  //this function displays all the elements in the universe
  public void display() {

    //calls the display function of the camera
    myCamera.display();

    //for each celestial object
    for (int i = 0; i <  celestialObjects.size(); i++) {
      CelestialObject co =  celestialObjects.get(i);

      //calls the display and update function
      co.display();
      co.update();
    }
  }

  //Detects collision between the spaceship/camera and the celestial objects
  public void collision() {

    //for each celestial objects
    for (int i = 0; i < celestialObjects.size(); i++) {

      CelestialObject co = celestialObjects.get(i);

      //distance between the camera and each celestial object
      PVector distance = PVector.sub(myCamera.getLocation(), co.getLocation());

      //if distance is less than the mass of the celestial object times 4
      if (distance.mag() < co.getMass() * 4) { 

        //sets the distance magnitude to the mass of the celestial object times 4
        distance.setMag(co.getMass() * 4);

        //new camera location by adding the distance to the location of the celestial object
        PVector newCameraLocation = PVector.add(co.getLocation(), distance);

        //sets the new camera location
        myCamera.setLocation(newCameraLocation);
      }
    }
  }

  //returns the background image
  public PImage getBackground() {
    return background;
  }
}
  public void settings() {  size(1280, 800, P3D);  smooth(); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "--present", "--window-color=#666666", "--stop-color=#cccccc", "SpaceExploreFinal" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
